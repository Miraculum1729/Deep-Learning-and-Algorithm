# 利用Keras库对MNIST数据集进行研究

>姓名：潘冯谱(2018级本科)
>
>学校：华东理工大学
>
>专业：数学与应用数学

修改于 2020-10-22

### MNIST数据集

[官方文档](http://yann.lecun.com/exdb/mnist/)

The MNIST database of handwritten digits, available from this page, has a training set of 60,000 examples, and a test set of 10,000 examples. It is a subset of a larger set available from NIST. The digits have been size-normalized and centered in a fixed-size image.

It is a good database for people who want to try learning techniques and pattern recognition methods on real-world data while spending minimal efforts on preprocessing and formatting.

### 多层感知机网络

![](http://mp.ofweek.com/Upload/News/Img/member20047/201905/wx_article_20190526215523_1v9KVb.jpg)


```python
import warnings
warnings.filterwarnings("ignore")
```

## 导入MNIST数据集


```python
import tensorflow as tf
from tensorflow import keras
from keras.datasets import mnist

# 从Keras的数据集中导入MNIST数据集，分别构造训练集、测试集的特征和标签
(X_train, y_train), (X_test, y_test) = mnist.load_data()

print('训练集中共有{}个样本'.format(len(X_train)))
print('测试集中共有{}个样本'.format(len(X_test)))
```

    训练集中共有60000个样本
    测试集中共有10000个样本
    

## 可视化图像


```python
import matplotlib.pyplot as plt
%matplotlib inline
plt.rcParams['font.sans-serif']=['SimHei']  # 用来正常显示中文标签
plt.rcParams['axes.unicode_minus']=False  # 用来正常显示中文标签

import numpy as np
```


```python
# 训练数字图像的大小
X_train[0].shape
```




    (28, 28)




```python
# 打印训练集数据集中样本的图像
i = 10
plt.imshow(X_train[i])
plt.title('真实标签：'+str(y_train[i]))
plt.show()
```


    
![png](output_8_0.png)
    



```python
# 绘制像素热力图
def visualize_input(img, ax):
    # 先绘制数字的大图，然后对784个像素每个标注灰度值
    ax.imshow(img, cmap='gray')
    width, height = img.shape
    thresh = img.max()/2.5
    for x in range(width):
        for y in range(height):
            ax.annotate(str(round(img[x][y],2)), xy=(y,x),
                        horizontalalignment='center',
                        verticalalignment='center',
                        color='white' if img[x][y]<thresh else 'black')
i = 6  # 绘制数据集中索引为5的灰度图像
fig = plt.figure(figsize = (10,10))  # 设定图的总大小
ax = fig.add_subplot(111)
# 调用绘图函数
visualize_input(X_train[i], ax)
```


    
![png](output_9_0.png)
    



```python
import matplotlib.cm as cm
```


```python
# 绘制前16张图像
for i in range(16):
    plt.style.use({'figure.figsize':(15,15)})  # 设置图像大小
    plt.subplot(1,4,i%4+1)  #
    plt.imshow(X_train[i])
    title = '真实标签：{}'.format(str(y_train[i]))
    plt.title(title)
    plt.xticks([])  #关闭刻度线显示
    plt.yticks([])  #
    plt.axis('off')  #关闭坐标轴显示
    if i%4 == 3:
        plt.show()
```


    
![png](output_11_0.png)
    



    
![png](output_11_1.png)
    



    
![png](output_11_2.png)
    



    
![png](output_11_3.png)
    



```python
# 绘制前16张图像的灰度图
for i in range(16):
    plt.style.use({'figure.figsize':(15,15)})  # 设置图像大小
    plt.subplot(1,4,i%4+1)  #
    plt.imshow(X_train[i], cmap='gray')
    title = '真实标签：{}'.format(str(y_train[i]))
    plt.title(title)
    plt.xticks([])  #关闭刻度线显示
    plt.yticks([])  #
    plt.axis('off')  #关闭坐标轴显示
    if i%4 == 3:
        plt.show()
```


    
![png](output_12_0.png)
    



    
![png](output_12_1.png)
    



    
![png](output_12_2.png)
    



    
![png](output_12_3.png)
    


## 预处理——归一化


```python
# 缩放像素值[0,255] --> [0,1]
# 神经网络模型对输入数据幅度敏感，进行数据归一化预处理可以让后续神经网络模型收敛速度更快，效果更好
X_train = X_train.astype('float32')/255
X_test = X_test.astype('float32')/255
```

## 预处理——标签独热向量编码

### One-Hot-Encoding
在构造损失函数时，用One-Hot编码向量计算交叉熵损失函数


```python
from keras.utils import np_utils

# 将训练集和测试集的标签转化为One-Hot编码向量
y_train = np_utils.to_categorical(y_train, 10)
y_test = np_utils.to_categorical(y_test, 10)
```

## 构建MLP多层感知机神经网络

Dense 密集层，也就是全连接层

Dropout 丢弃层，防止过拟合

Flatten 将28*28的图像拉平成784维的长向量


```python
from keras.models import Sequential
from keras.layers import Dense, Dropout, Flatten

model = Sequential()
model.add(Flatten(input_shape=(28,28)))

# 512个神经元的全连接神经网络，激活函数为Relu,Dropout率为0.2
model.add(Dense(512, activation='relu'))
model.add(Dropout(0.2))
          
# 512个神经元的全连接神经网络，激活函数为Relu,Dropout率为0.2
model.add(Dense(512, activation='relu'))
model.add(Dropout(0.2))
          
# 输出层，10个神经元，softmax输出，对应图像为10个数字的概率
model.add(Dense(10, activation='softmax'))
```


```python
model.summary()
```

    Model: "sequential"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    flatten (Flatten)            (None, 784)               0         
    _________________________________________________________________
    dense (Dense)                (None, 512)               401920    
    _________________________________________________________________
    dropout (Dropout)            (None, 512)               0         
    _________________________________________________________________
    dense_1 (Dense)              (None, 512)               262656    
    _________________________________________________________________
    dropout_1 (Dropout)          (None, 512)               0         
    _________________________________________________________________
    dense_2 (Dense)              (None, 10)                5130      
    =================================================================
    Total params: 669,706
    Trainable params: 669,706
    Non-trainable params: 0
    _________________________________________________________________
    


```python
model.compile(loss='categorical_crossentropy', optimizer='rmsprop', metrics=['accuracy'])
```

## 模型训练前，在测试集上进行评估

第一个数字是交叉熵损失，第二个数字是小数形式的准确率


```python
model.evaluate(X_test, y_test, verbose=1)
```

    313/313 [==============================] - 2s 5ms/step - loss: 2.3391 - accuracy: 0.1276
    




    [2.339078664779663, 0.12759999930858612]



## 训练模型

训练的时候，每步传入128个样本，总共训练10轮，也就是完整遍历10遍训练集，每轮训练后在验证集上进行测试

验证集是从60,000张原始训练集中抽选出来的1/5样本，也就是12,000张样本，原始训练集中剩下的48,000个样本作为训练集

使用ModekCheckpoint及时存储验证集上准确率最高的最优模型，存储为当前目录下的"mnist.model.best.hdf5"文件，早停可以防止过拟合

[Keras_ModekCheckpoint官方文档](https://keras.io/api/callbacks/#modekcheckpoint)


```python
from keras.callbacks import ModelCheckpoint

checkpointer = ModelCheckpoint(filepath='mnist.model.best.hdf5', verbose=1, save_best_only=True)

hist = model.fit(X_train, y_train, batch_size=128, epochs=10, validation_split=0.2, callbacks=[checkpointer], verbose=1, shuffle=True)
```

    Epoch 1/10
    374/375 [============================>.] - ETA: 0s - loss: 0.2733 - accuracy: 0.9151
    Epoch 00001: val_loss improved from inf to 0.12532, saving model to mnist.model.best.hdf5
    375/375 [==============================] - 14s 36ms/step - loss: 0.2730 - accuracy: 0.9151 - val_loss: 0.1253 - val_accuracy: 0.9616
    Epoch 2/10
    375/375 [==============================] - ETA: 0s - loss: 0.1087 - accuracy: 0.9673
    Epoch 00002: val_loss improved from 0.12532 to 0.10226, saving model to mnist.model.best.hdf5
    375/375 [==============================] - 13s 35ms/step - loss: 0.1087 - accuracy: 0.9673 - val_loss: 0.1023 - val_accuracy: 0.9701
    Epoch 3/10
    375/375 [==============================] - ETA: 0s - loss: 0.0796 - accuracy: 0.9754 ETA: 0s - loss: 0.0
    Epoch 00003: val_loss improved from 0.10226 to 0.09716, saving model to mnist.model.best.hdf5
    375/375 [==============================] - 13s 34ms/step - loss: 0.0796 - accuracy: 0.9754 - val_loss: 0.0972 - val_accuracy: 0.9722
    Epoch 4/10
    375/375 [==============================] - ETA: 0s - loss: 0.0629 - accuracy: 0.9806
    Epoch 00004: val_loss improved from 0.09716 to 0.09634, saving model to mnist.model.best.hdf5
    375/375 [==============================] - 13s 34ms/step - loss: 0.0629 - accuracy: 0.9806 - val_loss: 0.0963 - val_accuracy: 0.9731
    Epoch 5/10
    375/375 [==============================] - ETA: 0s - loss: 0.0519 - accuracy: 0.9845 ETA: 1s - loss: 0.0508 - accu - ETA - ETA: 0s - loss: 0.0518 - accuracy: 0.98
    Epoch 00005: val_loss improved from 0.09634 to 0.08930, saving model to mnist.model.best.hdf5
    375/375 [==============================] - 13s 34ms/step - loss: 0.0519 - accuracy: 0.9845 - val_loss: 0.0893 - val_accuracy: 0.9774
    Epoch 6/10
    375/375 [==============================] - ETA: 0s - loss: 0.0427 - accuracy: 0.9869 ETA: 3s - loss: 0.0421 - accura -
    Epoch 00006: val_loss did not improve from 0.08930
    375/375 [==============================] - 13s 33ms/step - loss: 0.0427 - accuracy: 0.9869 - val_loss: 0.0965 - val_accuracy: 0.9772
    Epoch 7/10
    374/375 [============================>.] - ETA: 0s - loss: 0.0400 - accuracy: 0.9876
    Epoch 00007: val_loss did not improve from 0.08930
    375/375 [==============================] - 13s 36ms/step - loss: 0.0400 - accuracy: 0.9875 - val_loss: 0.1009 - val_accuracy: 0.9796
    Epoch 8/10
    375/375 [==============================] - ETA: 0s - loss: 0.0338 - accuracy: 0.9895
    Epoch 00008: val_loss did not improve from 0.08930
    375/375 [==============================] - 13s 35ms/step - loss: 0.0338 - accuracy: 0.9895 - val_loss: 0.1046 - val_accuracy: 0.9775
    Epoch 9/10
    374/375 [============================>.] - ETA: 0s - loss: 0.0307 - accuracy: 0.9907
    Epoch 00009: val_loss did not improve from 0.08930
    375/375 [==============================] - 13s 34ms/step - loss: 0.0307 - accuracy: 0.9907 - val_loss: 0.1075 - val_accuracy: 0.9800
    Epoch 10/10
    375/375 [==============================] - ETA: 0s - loss: 0.0282 - accuracy: 0.9917
    Epoch 00010: val_loss did not improve from 0.08930
    375/375 [==============================] - 13s 36ms/step - loss: 0.0282 - accuracy: 0.9917 - val_loss: 0.0988 - val_accuracy: 0.9809
    

## 可视化训练过程的信息


```python
import matplotlib.pyplot as plt
%matplotlib inline

def plot_history(network_history):
    plt.figure()
    plt.xlabel('Epochs')
    plt.ylabel('Loss')
    plt.plot(network_history.history['loss'])
    plt.plot(network_history.history['val_loss'])
    plt.legend(['Training', 'Validation'])
    
    plt.figure()
    plt.xlabel('Epochs')
    plt.ylabel('Accuracy')
    plt.plot(network_history.history['accuracy'])
    plt.plot(network_history.history['val_accuracy'])
    plt.legend(['Training', 'Validation'], loc='lower right')
    plt.show()
    
plot_history(hist)
```


    
![png](output_26_0.png)
    



    
![png](output_26_1.png)
    


## 加载训练过程中验证集上准确率最高的最优模型


```python
model.load_weights('mnist.model.best.hdf5')
```

## 在测试集上评估模型


```python
model.evaluate(X_test, y_test, verbose=1)
```

    313/313 [==============================] - 2s 6ms/step - loss: 0.0804 - accuracy: 0.9798
    




    [0.08036404103040695, 0.9797999858856201]



## 对一些样本进行预测


```python
i = 6
img_test = X_test[i].reshape(-1,28,28)
prediction = model.predict(img_test)[0]
```


```python
prediction
```




    array([8.29867154e-13, 5.37453548e-09, 3.14205294e-11, 1.04868544e-10,
           9.99961734e-01, 9.69839409e-09, 1.04460093e-10, 2.32867254e-08,
           1.98170437e-05, 1.84575347e-05], dtype=float32)




```python
np.argmax(prediction)
```




    4




```python
i = 10

plt.imshow(X_test[i])
img_test = X_test[i].reshape(-1,28,28)
prediction = model.predict(img_test)[0]

title = '真实标签：{}\n预测标签：{}'.format(np.argmax(y_test[i]), np.argmax(prediction))
plt.title(title)
plt.show()

plt.bar(range(10), prediction)
plt.title('预测概率分布')
plt.xticks([0,1,2,3,4,5,6,7,8,9])
plt.show()
```


    
![png](output_35_0.png)
    



    
![png](output_35_1.png)
    

